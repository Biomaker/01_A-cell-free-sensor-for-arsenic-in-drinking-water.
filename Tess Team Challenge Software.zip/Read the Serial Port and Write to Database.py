# -*- coding: utf-8 -*-
"""
Created on Fri Jun 30 14:41:50 2017
This code reads from the serial port and parses a single into SMS
into constituent components and inserts them into a database. 

@author: Tess Skyrme
ts676@cam.ac.uk

"""
 # %% Write Readings to SQLite  
import sqlite3
sqlite_file = 'Arsenic_Readings_1.sqlite'    # name of the sqlite database file
Table_1 = 'Table_1'  # name of the table to be created
new_field='ID'
field_type='INTEGER'


conn = sqlite3.connect(sqlite_file)
c = conn.cursor()


# %% 
#Importing serial port module and creating a .txt file
import serial
import numpy as np
#opens file with name of "Sensor_Data.txt"
f = open("C:/Users/ts676/Dropbox/Sensor Team Challenge 2017/WP5 - Software \
         /Website/Download Data/Sensor_Data.txt","w") 
f.write("Latest Sensor Data - 25/07/2017.\n")    
f.close()


# %% 
#Reading from Serial Port
ser = serial.Serial("COM6", 9600)
while True:
    script=ser.readline() 
    print(script)

    if(script.startswith("Location")==True):
        script_array=script.split(',')  
        Date=script[17:25]
        print(Date)
        Time=script[25:29]
        print(Time)
        GPS_long=script_array[4]
        print(GPS_long)
        GPS_lat=script_array[5]
        print(GPS_lat)
        Ars=script_array[1]
        print(Ars)
    #ser.close()
# %%       
 #Writing Readings to a .txt file    
        f = open("C:/Users/ts676/Dropbox/Sensor Team Challenge 2017/WP5 - \
 Software/Website/Download Data/Sensor_Data.txt","a+b") 
        f.write(Date)
        f.write(';')
        f.write(Time)
        f.write(';')
        f.write(GPS_long)
        f.write(';')
        f.write(GPS_lat)
        f.write(';')
        f.write(Ars + "\r\n")
        f.close()

#%% Update DataBase With Readings
        c.execute("INSERT INTO Table_1 \
 (Date,Time,Longitude,Lattitude,Concentration)VALUES (?,?,?,?,?)", \
 (Date,Time, GPS_long, GPS_lat,Ars,))
        conn.commit()
       
        
        
        
   
    
        
   
        


        

    
    



