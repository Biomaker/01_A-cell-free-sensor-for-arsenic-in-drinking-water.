# -*- coding: utf-8 -*-
"""
Created on Tue Jul 11 14:58:47 2017
Creating the Arsenic Reading DataBase
@author: ts676
"""
'clear all'



# %% Cell 1
# Connecting to the database file Preamble
import sqlite3
sqlite_file = 'Arsenic_Readings_1.sqlite'    # name of the sqlite database file
Table_1 = 'Table_1'  # name of the table to be created
new_field='ID'
field_type='INTEGER'


conn = sqlite3.connect(sqlite_file)
c = conn.cursor()

#%% Cell 2

c.execute('CREATE TABLE {tn} ({nf} {ft} PRIMARY KEY)'\
        .format(tn=Table_1, nf=new_field, ft=field_type))
        

# %% Cell 3
#Create Column for Date 
new_column1='Date'
column_type='TEXT'
c.execute("ALTER TABLE {tn} ADD COLUMN '{cn}' {ct}"\
          .format(tn=Table_1, cn=new_column1, ct=column_type))
#%% Cell 4
#Create Column for Time
new_column5='Time'
column_type='TEXT'
c.execute("ALTER TABLE {tn} ADD COLUMN '{cn}' {ct}"\
          .format(tn=Table_1, cn=new_column5, ct=column_type))
# %% Cell 5
#Create Column for Longitude
new_column2='Longitude'
column_type='INTEGER'
c.execute("ALTER TABLE {tn} ADD COLUMN '{cn}' {ct}"\
          .format(tn=Table_1, cn=new_column2, ct=column_type))


# %% Cell 6
#Create Column for Lattitude
new_column3='Lattitude'
column_type='INTEGER'
c.execute("ALTER TABLE {tn} ADD COLUMN '{cn}' {ct}"\
          .format(tn=Table_1, cn=new_column3, ct=column_type))

# %% Cell 7
#Create Column for Arsenic Reading
new_column4='Concentration'
column_type='INTEGER'
c.execute("ALTER TABLE {tn} ADD COLUMN '{cn}' {ct}"\
          .format(tn=Table_1, cn=new_column4, ct=column_type))

#%% Cell 8

conn.commit()
#conn.close()
