
 <html>
 <body>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
 <title>Arsenic Poisioned Well Database: Locations and Concentrations</title>
 <script src="https://maps.googleapis.com/maps/api/js?
 key=AIzaSyBTaAwvAOWYRKwrTKQ5-1p4LA9l_PqmLlo&callback=myMap"
		 type="text/javascript"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-pink.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
  <style> body,h1,h2,h3,h4,h5 {font-family: "Roboto", sans-serif} </style>
</head>

<body style="text-align: center">
  <!--
<style> body{background-color:#b3ffff;} margin:10;
</style>-->
<header class="w3-theme-d4" style="padding:12px; padding-top:1px; padding-bottom:1px">
  <h1>Cambridge Sensor CDT 2016/17</h1>
</header>
<div class="w3-container">
<h2> Arsenic Database</h2>
</div>

<div>
 <table class="w3-table-all w3-hoverable">
	<tr class="w3-theme-l3">

		<th> Date </th>
		<th> Time (GMT-1) </th>
		<th> Lattitude </th>
		<th> Longitude</th>
		<th> Concentration (ppb) </th>

	</tr>



	<?php
	//Arsenic_Readings_1_conn_table.php

		$db = new SQLite3('C:\xampp\htdocs/Arsenic_Readings_1.sqlite');

		$result = $db->query('SELECT * FROM Table_1 ' );
					//while ($row = $result->fetchArray())
						//var_dump($row);


		$count = $db->querySingle("SELECT COUNT(*) as count FROM Table_1");
		//echo $count;

		if
		($count > 0) {
		// output data of each row
		while($row = $result->fetchArray()) {
			//echo "<br> id: ". $row["ID"]. " - Name: ". $row["Date"]. " " .
			$row["Lattitude"] . "<br>";
			
			echo "<td align=\"center\" style=\"font-family:verdana\" > ". 
				$row['Date']. " </td>  ";
			echo "<td align=\"center\" style=\"font-family:verdana\">   ". 
			$row['Time']. "  </td>  ";
			echo "<td align=\"center\" style=\"font-family:verdana\">   ". 
			$row['Lattitude']. "  </td>  ";
			echo "<td align=\"center\" style=\"font-family:verdana\">  ". 
			$row['Longitude']. "  </td>  ";
			echo "<td align=\"center\" style=\"font-family:verdana\">   ". 
			$row['Concentration']. "  </td>  </tr>";

		}
		} else {
		echo "0 results";
		}

			?>

	</table>
</div>


<div class="w3-container">
<h1>Well Locations</h1>

<div id="map" style="width:100%;height:40vh; align=center"></div>
  <script> type="text/javascript"</script>

<script>

function myMap() {
//Setting up the Original Map - Centered on Cambridge


 var locations = [

 <?php
//Connecting to the Database and fetching the Lattitude and Longitude Database
$db = new SQLite3('C:\Users\ts676\Dropbox\Sensor Team Challenge 2017\WP5 - Software\
					Database\SQLite/Arsenic_Readings_1.sqlite');
$result= $db->query('SELECT * FROM Table_1');


while ($donnees = $result->fetchArray()) {

echo "[";
echo "'";
echo $donnees['Date'];
echo "'";
echo ",";
echo $donnees['Lattitude'] ;
echo ",";
echo $donnees['Longitude'] ;
echo ",";
echo "'";
echo "Concentration=";
echo $donnees ['Concentration'];
echo " ppb";
echo ", Date: ";
echo $donnees ['Date'];
echo ", Time:" ;
echo $donnees ['Time'];
echo "'";
echo "],";
echo "\r\n";
}
echo "];";

?>

type = "text/javascript"
var x = 42.3154
var y = 43.3569
var myCenter1 = new google.maps.LatLng(x,y );
var mapCanvas = document.getElementById("map");
var mapOptions = {center: myCenter1, zoom: 3};
var map = new google.maps.Map(mapCanvas, mapOptions);
//var marker = new google.maps.Marker({position:myCenter1});
//marker.setMap(map);

var infowindow = new google.maps.InfoWindow();
var marker, i;

    for (i = 0; i < locations.length; i++) {
		var image = 'https://maps.gstatic.com/mapfiles/ms2/micons/water.png'
		marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][2], locations[i][1]),
        map: map,
		//icon: image
		});

		 google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][3], locations [i] [0]);
          infowindow.open(map, marker);
        }
      })(marker, i));





		}



 }


//var marker1 =new google.maps.LatLng(x1,y1);
//var placerMarker=new google.maps.Marker({position:marker1});
//marker.setMap(map);



//}
</script>
<script src="https://maps.googleapis.com/maps/api/js?
key=AIzaSyBTaAwvAOWYRKwrTKQ5-1p4LA9l_PqmLlo&callback=myMap"
		 type="text/javascript"></script>

</body>
</html>
